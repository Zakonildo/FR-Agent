from gui import *
from PIL import Image as pilImage
from tools.visual.VideoSource import *
from tools.visual.methods.OpenPifPafMethod import *
from tools.visual.methods.BlazePoseMethod import *
from tools.visual.FallRiskCalculator import *
from tools.visual.Database import *
import gc
import os, psutil

# Main Class responsible for managing the Dr.Alex Application.
class DrAlex:
    def __init__(self):
        self.camera = VideoSource()
        self.oppPredictor = OpenPifPafTracking()
        self.blazePosePredictor = BlazePoseTracking()
        self.method = "OpenPifPaf"
        self.appAnswer = "Hello! I'm Dr. Alex and I'm here to help!"
        self.muted = False
        self.userMsg = ""

        self.requestMethod = False
        self.requestUpDown = 0

        self.lastFramePoints = []
        self.oppTestLastFrames = {
            1.0 : [],
            1.1 : [],
            1.2 : [],
            1.3 : [],
            1.4 : [],
            1.5 : [],
            1.6 : [],
            1.7 : [],
            1.8 : [],
            1.9 : [],
            2.0 : [],
            2.1 : [],
            2.2 : [],
            2.3 : [],
            2.4 : [],
            2.5 : [],
            2.6 : [],
            2.7 : [],
            2.8 : [],
            2.9 : [],
            3.0 : [],
            3.1 : [],
            3.2 : [],
            3.3 : [],
            3.4 : [],
            3.5 : [],
            3.6 : [],
            3.7 : [],
            3.8 : [],
            3.9 : [],
            4.0 : [],
            4.1 : [],
            4.2 : [],
            4.3 : [],
            4.4 : [],
            4.5 : [],
            4.6 : [],
            4.7 : [],
            4.8 : [],
            4.9 : [],
            5.0 : [],
            5.1 : [],
            5.2 : [],
            5.3 : [],
            5.4 : [],
            5.5 : [],
            5.6 : [],
            5.7 : [],
            5.8 : [],
            5.9 : [],
            6.0 : [],
            6.1 : [],
            6.2 : [],
            6.3 : [],
            6.4 : [],
            6.5 : [],
            6.6 : [],
            6.7 : [],
            6.8 : [],
            6.9 : [],
            7.0 : [],
            7.1 : [],
            7.2 : [],
            7.3 : [],
            7.4 : [],
            7.5 : [],
            7.6 : [],
            7.7 : [],
            7.8 : [],
            7.9 : [],
            8.0 : [],
            8.1 : [],
            8.2 : [],
            8.3 : [],
            8.4 : [],
            8.5 : [],
            8.6 : [],
            8.7 : [],
            8.8 : [],
            8.9 : [],
            9.0 : [],
            9.1 : [],
            9.2 : [],
            9.3 : [],
            9.4 : [],
            9.5 : [],
            9.6 : [],
            9.7 : [],
            9.8 : [],
            9.9 : [],
            10.0 : []}
        
        self.blazePoseTestLastFrame = {
            0 : [],
            1 : [],
            2 : []}

        self.winWidth = 1600
        self.winHeight = 900
        self.gui = GUI(self.winWidth, self.winHeight)

        self.gui.setMenuFunction(0, self.quit)
        self.gui.setMenuFunction(1, self.gui.changeToCamera)
        self.gui.setMenuFunction(2, self.gui.changeDialog)
        self.gui.setMenuFunction(3, self.mute)

        self.gui.bind('<Left>', self.requestMethodChange)
        self.gui.bind('<Right>', self.requestMethodChange)
        self.gui.bind('<Up>', self.requestUp)
        self.gui.bind('<Down>', self.requestDown)

        self.resultIndex = 1

        self.oppTestScale = 1.0
        self.blazePoseTestComplexity = 0
        self.nTest = 1

        #if self.method == "OpenPifPaf":
            #self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%.1f" % self.oppTestScale)

        #else:
            #self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%d" % self.blazePoseTestComplexity)

        #if checkDatabase(self.dbName) == False:
            #createDatabase(self.dbName)
            #"DR.ALEX_FRAME_DATABASE"

        self.testDBSet = []
        self.testDBRow = []
        self.dbIndex = 0

        for i in range(10, 11):
            self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%.1f" % self.oppTestScale)

            if checkDatabase(self.dbName) == False:
                createDatabase(self.dbName)

            dbWB, dbRow = loadDatabase(self.dbName)
            self.testDBSet.append(dbWB)
            self.testDBRow.append(dbRow)
            self.dbIndex += 1
            self.oppTestScale += 0.1

        self.oppTestScale = 1.0
        self.method = "BlazePose"

        for i in range(0, 3):
            self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%d" % self.blazePoseTestComplexity)

            if checkDatabase(self.dbName) == False:
                createDatabase(self.dbName)

            dbWB, dbRow = loadDatabase(self.dbName)
            self.testDBSet.append(dbWB)
            self.testDBRow.append(dbRow)
            self.dbIndex += 1
            self.blazePoseTestComplexity += 1

        self.blazePoseTestComplexity = 0
        self.method = "OpenPifPaf"

        self.dbIndex = 0

        # self.dbName = "Result_" + str(self.resultIndex)

        # if checkDatabase(self.dbName) == False:
        #     createDatabase(self.dbName)

        # self.dbWB, self.dbRow = loadDatabase(self.dbName)

        return

    def run(self):
        while(self.nTest < 41):
            self.update()
            self.gui.update()

            if(self.requestMethod == True):
                self.requestMethod = False
                
                self.changeMethod()
            
            if (self.requestUpDown == 1):
                self.requestUpDown = 0
                if (self.method == "OpenPifPaf"):
                    self.oppPredictor.upScale()
                else:
                    self.blazePosePredictor.upComplexity()
            
            elif (self.requestUpDown == -1):
                self.requestUpDown = 0
                if (self.method == "OpenPifPaf"):
                    self.oppPredictor.downScale()
                else:
                    self.blazePosePredictor.downComplexity()
        
        self.quit()

    def update(self):
        if (self.muted == False):
            sourceFrame, newSource = self.camera.groundTruthGetFrame()
            if(newSource == True):
                #self.dbWB.save(self.dbName + ".xlsx")

                self.resultIndex += 1

                #if checkDatabase("Result_" + str(self.resultIndex)) == False:
                    #createDatabase("Result_" + str(self.resultIndex))

                #self.dbWB, self.dbRow = loadDatabase("Result_" + str(self.resultIndex))

                self.lastFramePoints = []
            
            frame = pilImage.fromarray(sourceFrame)
            res = self.camera.getResolution()

            predictions = []
            
            if (self.method == "OpenPifPaf"):
                oppPredictions, scale = self.oppPredictor.getPoints(frame, res)
                for i in range(0, len(oppPredictions)):
                    predictions.append(oppPredictions[i].data)
                self.gui.updateScale(scale)

            else:
                blazePosePredictions, complexity = self.blazePosePredictor.getPoints(sourceFrame, res)
                self.gui.updateComplexity(complexity)
                if (blazePosePredictions != []):
                    predictions.append(blazePosePredictions)

            if(self.gui.onCamera):
                self.gui.updateCameraFrame(frame)
                self.gui.drawPredictions(predictions)

            fps = self.gui.drawFPS()

            if self.lastFramePoints != [] and predictions != []:
                fallRisk, S_k_i, S_fps, S_res = calculateFallRisk(self.lastFramePoints, predictions[0], fps, res[0], 0.5)
                #insertDatabaseData(predictions[0], self.dbWB, self.dbRow, fallRisk, S_k_i, S_fps, S_res, float("%2.2f" % fps))
                #self.dbRow += 1
                self.gui.updateFallRisk(fallRisk)

            else:
                self.gui.updateFallRisk(-1.0)

            if (predictions != []):
                self.lastFramePoints = predictions[0]
        
        else:
            self.gui.drawFPS()
            self.gui.updateFallRisk(0.0)
            time.sleep(0.005)

        return
        
    def generateResultsUpdate(self):

        dbProb = 0.001

        sourceFrame, newSource = self.camera.groundTruthGetFrame()

        dbIndex = 0

        if(newSource == True):
            for i in range(10, 11):
                self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%.1f" % self.oppTestScale)
                self.testDBSet[dbIndex].save(self.dbName + ".xlsx")
                self.oppTestScale += 0.1
                dbIndex += 1

            self.oppTestScale = 1.0
            self.method = "BlazePose"

            for i in range(0, 3):
                self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%d" % self.blazePoseTestComplexity)
                self.testDBSet[dbIndex].save(self.dbName + ".xlsx")
                self.blazePoseTestComplexity += 1
                dbIndex += 1

            self.method = "OpenPifPaf"

            dbIndex = 0

            self.blazePoseTestComplexity = 0

            self.resultIndex += 1
            self.oppTestLastFrames = {
                1.0 : [],
                1.1 : [],
                1.2 : [],
                1.3 : [],
                1.4 : [],
                1.5 : [],
                1.6 : [],
                1.7 : [],
                1.8 : [],
                1.9 : [],
                2.0 : [],
                2.1 : [],
                2.2 : [],
                2.3 : [],
                2.4 : [],
                2.5 : [],
                2.6 : [],
                2.7 : [],
                2.8 : [],
                2.9 : [],
                3.0 : [],
                3.1 : [],
                3.2 : [],
                3.3 : [],
                3.4 : [],
                3.5 : [],
                3.6 : [],
                3.7 : [],
                3.8 : [],
                3.9 : [],
                4.0 : [],
                4.1 : [],
                4.2 : [],
                4.3 : [],
                4.4 : [],
                4.5 : [],
                4.6 : [],
                4.7 : [],
                4.8 : [],
                4.9 : [],
                5.0 : [],
                5.1 : [],
                5.2 : [],
                5.3 : [],
                5.4 : [],
                5.5 : [],
                5.6 : [],
                5.7 : [],
                5.8 : [],
                5.9 : [],
                6.0 : [],
                6.1 : [],
                6.2 : [],
                6.3 : [],
                6.4 : [],
                6.5 : [],
                6.6 : [],
                6.7 : [],
                6.8 : [],
                6.9 : [],
                7.0 : [],
                7.1 : [],
                7.2 : [],
                7.3 : [],
                7.4 : [],
                7.5 : [],
                7.6 : [],
                7.7 : [],
                7.8 : [],
                7.9 : [],
                8.0 : [],
                8.1 : [],
                8.2 : [],
                8.3 : [],
                8.4 : [],
                8.5 : [],
                8.6 : [],
                8.7 : [],
                8.8 : [],
                8.9 : [],
                9.0 : [],
                9.1 : [],
                9.2 : [],
                9.3 : [],
                9.4 : [],
                9.5 : [],
                9.6 : [],
                9.7 : [],
                9.8 : [],
                9.9 : [],
                10.0 : []}
        
            self.blazePoseTestLastFrame = {
                0 : [],
                1 : [],
                2 : []}
            
            self.nTest += 1

            self.testDBSet = []
            self.testDBRow = []

            for i in range(10, 11):
                self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%.1f" % self.oppTestScale)

                if checkDatabase(self.dbName) == False:
                    createDatabase(self.dbName)

                dbWB, dbRow = loadDatabase(self.dbName)
                self.testDBSet.append(dbWB)
                self.testDBRow.append(dbRow)
                dbIndex += 1
                self.oppTestScale += 0.1

            self.oppTestScale = 1.0
            self.method = "BlazePose"

            for i in range(0, 3):
                self.dbName = "Result_" + str(self.resultIndex) + "_" + self.method + "_" + ("%d" % self.blazePoseTestComplexity)

                if checkDatabase(self.dbName) == False:
                    createDatabase(self.dbName)

                dbWB, dbRow = loadDatabase(self.dbName)
                self.testDBSet.append(dbWB)
                self.testDBRow.append(dbRow)
                dbIndex += 1
                self.blazePoseTestComplexity += 1

            self.blazePoseTestComplexity = 0
            self.method = "OpenPifPaf"
            dbIndex = 0
        
        for i in range(10, 11):
            if(i != 10):
                self.oppPredictor.upScale()
                self.oppTestScale += 0.1
            
            self.testUpdate(sourceFrame, newSource, dbProb, dbIndex)
            dbIndex += 1
            self.gui.update()
        
        self.oppPredictor.resetScale()
        self.oppTestScale = 1.0
        self.method = "BlazePose"
        
        for i in range(0, 3):
            if(i != 0):
                self.blazePosePredictor.upComplexity()
                self.blazePoseTestComplexity += 1
            
            self.testUpdate(sourceFrame, newSource, dbProb, dbIndex)
            dbIndex += 1
            self.gui.update()
        
        self.blazePosePredictor.resetComplexity()
        self.blazePoseTestComplexity = 0
        self.method = "OpenPifPaf"

        del sourceFrame
        del newSource
        del dbProb
        gc.collect()

        return

    def testUpdate(self, sourceFrame, newSource, dbProb, dbIndex):
        
        frame = pilImage.fromarray(sourceFrame)
        res = self.camera.getResolution()

        predictions = []
        
        if (self.method == "OpenPifPaf"):
            oppPredictions, scale = self.oppPredictor.getPoints(frame, res)
            for i in range(0, len(oppPredictions)):
                predictions.append(oppPredictions[i].data)
            self.gui.updateScale(scale)

        else:
            blazePosePredictions, complexity = self.blazePosePredictor.getPoints(sourceFrame, res)
            self.gui.updateComplexity(complexity)
            if (blazePosePredictions != []):
                predictions.append(blazePosePredictions)

        if(self.gui.onCamera):
            self.gui.updateCameraFrame(frame)
            self.gui.drawPredictions(predictions)

        fps = self.gui.drawFPS()

        if(self.method == "OpenPifPaf"):
            if self.oppTestLastFrames[scale] != [] and predictions != []:
                    fallRisk, S_k_i, S_fps, S_res = calculateFallRisk(self.oppTestLastFrames[scale], predictions[0], fps, res[0], dbProb)
                    insertDatabaseData(predictions[0], self.testDBSet[dbIndex], self.testDBRow[dbIndex], fallRisk, S_k_i, S_fps, S_res, float("%2.2f" % fps))
                    self.testDBRow[dbIndex] += 1
                    self.gui.updateFallRisk(fallRisk)
            else:
                preds = []
                for i in range(0, 17):
                    preds.append(["N/A", "N/A", "N/A"])
                
                insertDatabaseData(preds, self.testDBSet[dbIndex], self.testDBRow[dbIndex], "N/A", "N/A", "N/A", "N/A", float("%2.2f" % fps))
                self.testDBRow[dbIndex] += 1
                self.gui.updateFallRisk(-1.0)
        else:
            if self.blazePoseTestLastFrame[complexity] != [] and predictions != []:
                fallRisk, S_k_i, S_fps, S_res = calculateFallRisk(self.blazePoseTestLastFrame[complexity], predictions[0], fps, res[0], dbProb)
                insertDatabaseData(predictions[0], self.testDBSet[dbIndex], self.testDBRow[dbIndex], fallRisk, S_k_i, S_fps, S_res, float("%2.2f" % fps))
                self.testDBRow[dbIndex] += 1
                self.gui.updateFallRisk(fallRisk)

            else:
                preds = []
                for i in range(0, 17):
                    preds.append(["N/A", "N/A", "N/A"])
                
                insertDatabaseData(preds, self.testDBSet[dbIndex], self.testDBRow[dbIndex], "N/A", "N/A", "N/A", "N/A", float("%2.2f" % fps))
                self.testDBRow[dbIndex] += 1
                self.gui.updateFallRisk(-1.0)

        if (predictions != []):
            if(self.method == "OpenPifPaf"):
                self.oppTestLastFrames[scale] = predictions[0]
            
            else:
                self.blazePoseTestLastFrame[complexity] = predictions[0]
        
        return

    def mute(self):
        self.muted = self.gui.muteAgent()
        return
    
    def changeMethod(self):
        if (self.method == "OpenPifPaf"):
            self.method = "BlazePose"

        else:
             self.method = "OpenPifPaf"

        self.gui.updateMethod(self.method)
        return
    
    def requestMethodChange(self, carry):
        self.requestMethod = True
        return True
    
    def requestUp(self, carry):
        self.requestUpDown = 1
        return

    def requestDown(self, carry):
        self.requestUpDown = -1
        return


    def quit(self):
        #self.dbWB.save(self.dbName + ".xlsx")
        self.gui.destroy()
        return