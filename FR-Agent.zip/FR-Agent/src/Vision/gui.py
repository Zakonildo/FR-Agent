import tkinter as tk
import time
from PIL import ImageTk as pilImageTk
from tools.visual.SkeletonDraw import *
import os

# Class responsible for the background of Dr.Alex Application.
class Background(tk.Frame):
    def __init__(self, root):
        self.res = root.getResolution()

        super().__init__(root, width=self.res[0], height=self.res[1], bg="#195FA9")

        self.dialogImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Text_Label.png")
        self.backgroundImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Background.png")

        self.background = tk.Label(self, image=self.backgroundImage, width=self.res[0], height=self.res[1], bd=-2)
        self.background.place(x=0, y=0, anchor=tk.NW)

        self.dialog = tk.Label(self, image=self.dialogImage, width=1400, height=50, text="Hello, I'm Dr. Alex and I'm here to help!", font="Arial 24 bold", compound="c", bg="#195FA9", fg="#E1E1E1")
        self.dialog.place(x=self.res[0]/2, y=self.res[1] - (self.res[1]/3.5), anchor=tk.CENTER)

        self.place(x=0 , y=0, anchor=tk.NW)
        return
    
    def changeText(self, text):
        self.dialog['text'] = text
        return

    def hide(self):
        self.place_forget()
        return
    
    def show(self):
        self.place(x=0 , y=0, anchor=tk.NW)
        return

# Class responsible for displaying the Camera of Dr.Alex Application.
class Camera(tk.Frame):
    def __init__(self, root):
        self.res = root.getResolution()

        super().__init__(root, width=self.res[0], height=self.res[1])

        self.display = tk.Canvas(self, width=self.res[0], height=self.res[1],bg="#000000", bd=-2)
        self.display.place(x=0, y=0, anchor=tk.NW)

        self.pixel = tk.PhotoImage(width=1, height=1)

        self.backButton = tk.Button(self, image=self.pixel, width=50, height=50, text="<", font="Arial 16 bold", compound="c", bg="#195FA9", fg="#E1E1E1", bd=-2)
        self.backButton.place(x=20, y=20, anchor=tk.NW)

        self.actualFrame = None

        self.place(x=0 , y=0, anchor=tk.NW)
        return

    def updateFrame(self, frame):
        self.display.delete("all")
        self.actualFrame = pilImageTk.PhotoImage(image=frame)

        self.display.create_image(self.res[0]/2, self.res[1]/2, image=self.actualFrame, anchor=tk.CENTER)
        return

    def hide(self):
        self.place_forget()
        return
    
    def show(self):
        self.place(x=0 , y=0, anchor=tk.NW)
        return

    def drawPoints(self, points, index):
        draw(points, self.display, index)
        return

# Class responsible for the menu of Dr.Alex Application.
class Menu(tk.Frame):
    def __init__(self, root):
        self.res = root.getResolution()

        super().__init__(root, width=self.res[0], height=self.res[1]/5, bg="#1A1A1A")

        self.buttons = []

        bText = ["EXIT", "SHOW", "TALK", "MUTE"]
        self.pixel = tk.PhotoImage(width=1, height=1)

        for i in range(0, 4):
            self.buttons.append( tk.Button(self, image=self.pixel, width=int(self.res[0]/4 - 12), height=int(self.res[1]/5), text=bText[i], font="Arial 24 bold", compound="c", bg="#262626", fg="#E1E1E1", bd=-2) )
            if(i == 0):
                self.buttons[-1].place(x=0 , y=0, anchor=tk.NW)
            else:
                self.buttons[-1].place(x=((self.res[0]/4) + 4)*i, y=0, anchor=tk.NW)

        self.place(x=0 , y=self.res[1], anchor=tk.SW)

        return

    def setButtonFunction(self, index, func):
        self.buttons[index].configure(command=func)
        return

    def hide(self):
        self.place_forget()
        return
    
    def show(self):
        self.place(x=0 , y=self.res[1], anchor=tk.SW)
        return
    
    def muteButtons(self):
        self.buttons[1]['state'] = "disabled"
        self.buttons[2]['state'] = "disabled"
        return

    def unmuteButtons(self):
        self.buttons[1]['state'] = "normal"
        self.buttons[2]['state'] = "normal"
        return

# Class responsible for containing all the needs of Dr.Alex Application.
class GUI(tk.Tk):
    def __init__(self, xRes, yRes):
        super().__init__()

        self.res = (xRes, yRes)
        
        self.title("Dr. Alex")
        self.geometry(str(xRes) + "x" + str(yRes))

        self.cameraStatus = False

        self.camera = Camera(self)
        self.bg = Background(self)
        self.menu = Menu(self)

        self.camera.backButton.configure(command=self.changeToMenu)

        self.fpsLast = time.time()
        self.fps = 0.0
        self.fpsInit = self.fpsLast

        self.pixel = tk.PhotoImage(width=1, height=1)

        self.fpsLabel = tk.Label(self, image=self.pixel, width=140, height=25, text=("FPS:  0.00"), font="Arial 14 bold", compound="c", bg="#00A5DE", fg="#E1E1E1", bd=-2,)
        self.fpsLabel.place(x=self.res[0] - 10, y=10, anchor=tk.NE)

        self.methodLabel = tk.Label(self, image=self.pixel, width=140, height=25, text=("OpenPifPaf"), font="Arial 14 bold", compound="c", bg="#00A5DE", fg="#E1E1E1", bd=-2,)
        self.methodLabel.place(x=self.res[0] - 10, y=40, anchor=tk.NE)

        self.scaleLabel = tk.Label(self, image=self.pixel, width=140, height=25, text=("Scale:  0.0"), font="Arial 14 bold", compound="c", bg="#0076BF", fg="#E1E1E1", bd=-2,)
        self.scaleLabel.place(x=self.res[0] - 10, y=70, anchor=tk.NE)

        self.fallRiskLabel = tk.Label(self, image=self.pixel, width=140, height=25, text=("Fall Risk:  0.00"), font="Arial 14 bold", compound="c", bg="#0076BF", fg="#E1E1E1", bd=-2,)
        self.fallRiskLabel.place(x=self.res[0] - 10, y=100, anchor=tk.NE)

        self.mute = False

        return

    def getResolution(self):
        return self.res

    def setMenuFunction(self, index, func):
        self.menu.setButtonFunction(index, func)
        return

    def changeToMenu(self):
        self.camera.hide()
        self.bg.show()
        self.menu.show()
        self.cameraStatus = False
        return

    def changeToCamera(self):
        self.bg.hide()
        self.menu.hide()
        self.camera.show()
        self.cameraStatus = True
        return

    def updateCameraFrame(self, frame):
        self.camera.updateFrame(frame)
        return
    
    def onCamera(self):
        return self.cameraStatus

    def drawPredictions(self, predictions):
        if predictions != []:
            for i in range(0, len(predictions)):
                self.camera.drawPoints(predictions[i], i)
        return

    def drawFPS(self):
        self.fpsLast = time.time()
        self.fps = 1/(self.fpsLast - self.fpsInit)
        self.fpsInit = self.fpsLast

        self.fpsLabel['text'] = ("FPS: %2.2f" % self.fps)
        return self.fps

    def updateScale(self, scale):
        self.scaleLabel['text'] = ("Scale: %2.1f" % scale)
        return

    def updateComplexity(self, complexity):
        self.scaleLabel['text'] = ("Complexity: %d" % complexity)
        return

    def updateFallRisk(self, fallRisk):
        if(fallRisk != -1.0):
            self.fallRiskLabel['text'] = ("Fall Risk: %1.2f" % fallRisk)
        else:
            self.fallRiskLabel['text'] = ("Fall Risk: N/A")

        if(fallRisk == -1.0):
            self.fallRiskLabel['bg'] = "#E0A034"
        elif(fallRisk < 0.10):
            self.fallRiskLabel['bg'] = "#0076BF"
        elif(fallRisk < 0.20):
            self.fallRiskLabel['bg'] = "#3375B7"
        elif(fallRisk < 0.30):
            self.fallRiskLabel['bg'] = "#3D74B5"
        elif(fallRisk < 0.40):
            self.fallRiskLabel['bg'] = "#7C6D95"
        elif(fallRisk < 0.50):
            self.fallRiskLabel['bg'] = "#976482"
        elif(fallRisk < 0.60):
            self.fallRiskLabel['bg'] = "#AF5A70"
        elif(fallRisk < 0.70):
            self.fallRiskLabel['bg'] = "#C04F60"
        elif(fallRisk < 0.80):
            self.fallRiskLabel['bg'] = "#D0414F"
        elif(fallRisk < 0.90):
            self.fallRiskLabel['bg'] = "#DC3040"
        elif (fallRisk <= 1.0):
            self.fallRiskLabel['bg'] = "#E61931"

        
        return

    def updateMethod(self, method):
        self.methodLabel['text'] = method
        return

    def changeDialog(self):
        self.bg.changeText("How can I help you?")
        return

    def muteAgent(self):
        dialogText = ""
        if(self.mute == False):
            self.bg.backgroundImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Muted.png")
            self.bg.dialogImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Muted_Label.png")
            dialogText = "Click \"Mute\" again to bring back my activity!"
            self.menu.muteButtons()
            self.mute = True
        else:
            self.bg.backgroundImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Background.png")
            self.bg.dialogImage = pilImageTk.PhotoImage(file = os.getcwd() + "/img/gui/Text_Label.png")
            dialogText = "If you need something, just call me by Dr.Alex."
            self.menu.unmuteButtons()
            self.mute = False

        self.bg.background.configure(image=self.bg.backgroundImage)
        self.bg.background['image'] = self.bg.backgroundImage
        self.bg.dialog.configure(image=self.bg.dialogImage)
        self.bg.dialog['image'] = self.bg.dialogImage
        self.bg.dialog['text'] = dialogText
        self.bg.update()

        return self.mute

    #def drawInfos(method=None, scale=None, complexity=None, fallRisk=None):
        #return