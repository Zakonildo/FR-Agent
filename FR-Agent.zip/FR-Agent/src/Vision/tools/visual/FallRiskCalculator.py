import math

def calculateFallRisk(lastFramePoints, currentFramePoints, fps, resolution, dbProb):
    k = [
        0.026,
        0.025,
        0.025, 
        0.035, 
        0.035, 
        0.079, 
        0.079, 
        0.072, 
        0.072, 
        0.062, 
        0.062, 
        0.107, 
        0.107, 
        0.087, 
        0.087, 
        0.089, 
        0.089]

    upperPart = 0
    kSummed = 1.138

    biggestK = 0
    
    for i in range(0, 17):
        if(currentFramePoints[i][0] < 0 or currentFramePoints[i][1] < 0):
            currentFramePoints[i][0] = 0.0
            currentFramePoints[i][1] = 0.0
        
        if(lastFramePoints[i][0] < 0 or lastFramePoints[i][1] < 0):
            lastFramePoints[i][0] = 0.0
            lastFramePoints[i][1] = 0.0

        dx = abs(currentFramePoints[i][0] - lastFramePoints[i][0])
        dy = abs(currentFramePoints[i][1] - lastFramePoints[i][1])

        if( dx > 0 or dy > 0 ):
            biggestK += k[i]
        if(
            currentFramePoints[i][0] > 0 and
            lastFramePoints[i][0] > 0 and
            currentFramePoints[i][1] > 0 and
            lastFramePoints[i][1] > 0):
            upperPart += math.sqrt(dx*dx + dy*dy) * k[i]

    S_k_i = biggestK/kSummed

    S_res = resolution/1280

    S_fps = 10/fps

    fr= upperPart/kSummed

    if (dbProb != 0.0):
        freedom = 5/dbProb
    else:
        freedom = 0

    try:
        fall_probability = fr/(freedom*S_k_i*S_res)
    
    except:
        fall_probability = -1.0

    if fall_probability > 1.0:
        return 1.0, S_k_i, S_fps, S_res
    else:
        return fall_probability, S_k_i, S_fps, S_res