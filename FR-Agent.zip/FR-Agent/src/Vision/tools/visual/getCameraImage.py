import cv2
import os
import torch
import time
import openpifpaf
import mediapipe as mp
from mediapipe.python.solutions import drawing_utils as mpDU
import SkeletonDraw
import FallRiskCalculator as frc
from PIL import Image as pilImage
from PIL import ImageTk as pilImageTk
from tkinter import *
import Database as db


print("CUDA Availability Status: " + str(torch.cuda.is_available()))
print("CUDA Version: " + str(torch.cuda_version))
print("STARTING...")

class App:
    def __init__(self, root):
        """
        As Tkinter is the GUI library choose here, the root should
        be saved in the class.

        Also our App it's dependent of a Canvas to display the info
        needed.
        """
        self.root = root
        self.cam = Canvas(self.root, width=1280, height=720)
        self.cam.place(x=0, y=0, anchor="nw")

        """
        Here the camera that will be used is chosen. Also, here it's
        defined the resolution of the camera.

        Remember, if you change the resolution of 1280x720, you'll
        have to change in the canvas also.
        """

        self.camCapture = cv2.VideoCapture(1 + cv2.CAP_DSHOW)
        # self.camCapture = cv2.VideoCapture("50_Ways_to_Fall.mp4")

        self.camCapture.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
        self.camCapture.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)

        """
        These variables allows you to change the complexity of BlazePose
        method. It requires two variable because I suppose you don't want
        the application to crash in the middle of the process because you
        changed the complexity.

        So the complexity variable will only change when the work of the
        BlazePose is done.
        """
        self.complexity = 2
        self.newComplexity = 2

        """
        The application supports two algorithms right now.

        The first one and the main algorithm is the OpenPifPaf.
        This algorithm captures the semantic points of people, cars
        and animals (Cat, Dog, etc.). It is no light-weighted, so it's
        recommended to accelerate it with CUDA processing.

        OpenPifPaf also supports multi-person tracking, so if that's
        the purpose, use OpenPifPaf.

        The second algorithm is the BlazePose, distributed by Google
        in the MediaPipe Library. It is kind of 'light-weighted' when
        compared to OpenPifPaf as it does not requirer a GPU to get
        some good FPS. As a consequence of it, the accuracy is not
        the same as OpenPifPaf.

        Also BlazePose supports some Complexity changes, when increased
        you may lose performance, but you gain in accuracy.
        """
        self.oppPredictor = openpifpaf.Predictor(checkpoint="shufflenetv2k16") # OpenPifPaf model
        self.mpPose = mp.solutions.pose.Pose(model_complexity=self.complexity, min_detection_confidence=0.7) # MediaPipe model

        """
        This variable is just a control variable to change the method in
        realtime.
        """
        self.method = 0 # Current using method

        """
        These variable only exist for one purpose. It is to
        get the current FPS.
        """

        self.fpsLast = time.time()
        self.fpsInit = time.time()
        self.fps = 0

        """
        The scale is referred only in OpenPifPaf. As OpenPifPaf is not
        a light-weighted application, downscaling the processing frame
        might help with performance. But remember, it'll increase the
        complexity if you lower the scale and it'll hit performance.
        """
        self.scale = 2.0
        self.newScale = 2.0

        self.debug = 0
        self.debugStatus = 0

        self.watermark = 0
        self.watermarkStatus = 0

        self.lastFramePoints = []

        """
        Just some binds to the keys utilized in application.
        """
        self.root.bind('<Left>', self.changeMethod)
        self.root.bind('<Right>', self.changeMethod)
        self.root.bind('.', self.upScale)
        self.root.bind(',', self.downScale)
        self.root.bind('<Up>', self.upComplexity)
        self.root.bind('<Down>', self.downComplexity)
        self.root.bind('<Escape>', self.kill)
        self.root.bind('d', self.changeDebug)
        self.root.bind('w', self.changeWatermark)

        if db.checkDatabase() == False:
            db.createDatabase()

        self.dbWB, self.dbRow = db.loadDatabase()

        return

    """
    This function is used to kill the Application.
    Everytime you want to kill it, you the [Esc] key.
    """
    def kill(self, carry):
        self.dbWB.save("DR.ALEX_FRAME_DATABASE.xlsx")
        self.method = -1
        self.root.destroy()
        return

    def changeDebug(self, carry):
        if self.debugStatus == 1:
            self.debugStatus = 0

        else:
            self.debugStatus = 1

        return

    def changeWatermark(self, carry):
        if self.watermarkStatus == 1:
            self.watermarkStatus = 0

        else:
            self.watermarkStatus = 1

        return

    """
    This function is used to increase the scale of the OpenPifPaf.
    """
    def upScale(self, carry):
        if self.method == 0:
            if self.newScale == 10.0:
                return

            else:
                self.newScale += 0.1
                self.newScale = round(self.newScale, 1)
        return

    """
    This function is used to reduce the scale of the OpenPifPaf.
    """
    def downScale(self, carry):
        if self.method == 0:
            if self.newScale == 1.0:
                return

            else:
                self.newScale -= 0.1
                self.newScale = round(self.newScale, 1)
        return

    """
    This function is used to increase the complexity of the BlazePose.
    """
    def upComplexity(self, carry):
        if self.method == 1:
            if self.newComplexity == 2:
                return

            else:
                self.newComplexity += 1
        return

    """
    This function is used to reduce the complexity of the BlazePose.
    """
    def downComplexity(self, carry):
        if self.method == 1:
            if self.newComplexity == 0:
                return

            else:
                self.newComplexity -= 1
        return

    """
    This function is used to changed through methods.
    You'll call it, every time you press the side arrow keys.
    """
    def changeMethod(self, carry):
        if self.method == 0:
            self.method = 1

        else:
            self.method = 0

        return

    """
    This is the most important function in here.

    This is used to loop so it can make the tracking a render the frames.
    It verify which method is being used at the moment and call it.

    If the method is 0 (OpenPifPaf), it'll call the OpenPifPaf.

    If the method is 1 (BlazePose), it'll call the BlazeOpen and then
    validate if after the processing the complexity was required to
    change. This is needed to not break the processes of tracking.

    If the complexity changed, the a new pose solution of BlazePose
    is created.
    """
    def loop(self):
        while(True):
            try:
                if self.method == 0:
                    self.trackOpenPifPaf()
                    if self.newScale != self.scale:
                        self.scale = self.newScale
                
                elif self.method == 1:
                    self.trackMediaPipe()
                    if self.newComplexity != self.complexity:
                        self.complexity = self.newComplexity
                        self.mpPose = mp.solutions.pose.Pose(model_complexity=self.complexity, min_detection_confidence=0.7)

                else:
                    break

                if self.debugStatus != self.debug:
                        self.debug = self.debugStatus
            except:
                time.sleep(0.01)

        return

    """
    This function get the frame of camera and converts from BGR to
    RGB.
    """
    def getFrame(self):
        check, frame = self.camCapture.read()
        return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    """
    This function calculates the current FPS and then return it.
    """
    def getFPS(self):

        self.fpsLast = time.time()
        self.fps = 1/(self.fpsLast - self.fpsInit)
        self.fpsInit = self.fpsLast

        return self.fps

    """
    This function get the FPS through the function self.getFPS() and
    then it draws it on screen.
    """
    def drawFPS(self):
        self.getFPS()

        self.cam.create_rectangle(1190, 10, 1270, 30, fill="#00A5DE", outline="")
        self.cam.create_text(1280-50, 20,fill="white",font="Arial 10 bold",text=(("FPS: %.2f" % self.fps)))
        return
    
    """
    This function get the OpenPifPaf prediction with the set scale at
    the constructor of the class.

    So, it first resizes the given frame to the downscale set and then
    the downscaled frame is passed to the OpenPifPaf's predictor algorithm.

    It geneartes 3 variable, being the first one the prediction points.
    """
    def getOpenPifPafPrediction(self, img):
        imgPifPaf = img.resize((int(1280/self.scale), int(720/self.scale)))

        predictions, gt_anns, image_meta = self.oppPredictor.pil_image(imgPifPaf)

        return predictions

    """
    This function is responsible for getting the predictions of the
    BlazePose algorithm. It transforms the normalized points to pixel
    and then removes the unused points, for exemple: finger, foot, hands.
    This is done to have a fair comparasion to the OpenPifPaf bone structure.
    """
    def getBlazePosePrediction(self, frame):
        predictions = self.mpPose.process(frame)

        points =[]

        try:
            for i in predictions.pose_landmarks.landmark:
                pixel = mpDU._normalized_to_pixel_coordinates(i.x, i.y, 1280, 720)
                if pixel != None and i.visibility >= 0.6:
                    points.append([pixel[0], pixel[1], i.visibility])
                else:
                    points.append([-1.0, -1.0, i.visibility])

            del points[32]
            del points[31]
            del points[30]
            del points[29]
            del points[22]
            del points[21]
            del points[20]
            del points[19]
            del points[18]
            del points[17]
            del points[10]
            del points[9]
            del points[6]
            del points[4]
            del points[3]
            del points[1]

            return points

        except:
            return []


    """
    This function is responsible for using the OpenPifPaf to track.

    It works very simple, first get the frame, draw at the 'native'
    resolution. Then make the prediction of frame through OpenPifPaf,
    and if something was captured, pass it to the SkeletonDraw to
    draw the full skeleton of what was tracked.

    After that, the Method being used is drew at the screen as well
    as the Dr.Alex watermark.

    Then, the canvas can be updated to display the full frame with
    all draws and then the command delete('all') is used to wipe
    the canvas for the next iteration.
    """
    def trackOpenPifPaf(self):
        frame = self.getFrame()
        img = pilImage.fromarray(frame)

        cameraImg = pilImageTk.PhotoImage(image=img)
        self.cam.create_image(0, 0, image = cameraImg, anchor = NW)

        predictions= self.getOpenPifPafPrediction(img)

        fallRisk = 0

        if predictions != []:
            index = 1
            for i in predictions:
                SkeletonDraw.draw(i.data, self.cam, self.scale, index, self.debug)
                index += 1

            if len(self.lastFramePoints) == 17:
                fallRiskResult = frc.calculateFallRisk(self.lastFramePoints, predictions[0].data, self.scale, self.fps, 1280)
                fallRisk = fallRiskResult[0]

                db.insertDatabaseData(predictions[0].data, self.dbWB, self.dbRow, fallRiskResult[0], fallRiskResult[1], fallRiskResult[2], fallRiskResult[3])
                self.dbRow += 1
            
            self.lastFramePoints = predictions[0].data

        self.cam.create_rectangle(10, 10, 88, 30, fill="#00A5DE", outline="")
        self.cam.create_text(0+48, 20,fill="white",font="Arial 10 bold",text="OpenPifPaf")

        self.cam.create_rectangle(10, 35, 106, 55, fill="#0076BF", outline="")
        self.cam.create_text(0+56, 45,fill="white",font="Arial 10 bold",text=(("Scale: %.1f" % self.scale)))

        self.cam.create_rectangle(10, 60, 106, 80, fill="#0076BF", outline="")
        self.cam.create_text(0+56, 70,fill="white",font="Arial 10 bold",text=(("FallRisk: %.2f" % fallRisk)))
        
        self.drawFPS()

        if self.watermark == 0:
            drAlexImg = pilImage.open("Dr.Alex_Watermark.png")
            drAlex_wm = pilImageTk.PhotoImage(image=drAlexImg)
            self.cam.create_image(1280-10, 720-10, image = drAlex_wm, anchor = SE)

            feimmersiveImg = pilImage.open("FEImmersive_Watermark.png")
            feimmersive_wm = pilImageTk.PhotoImage(image=feimmersiveImg)
            self.cam.create_image(10, 720-10, image = feimmersive_wm, anchor = SW)

        if self.watermark != self.watermarkStatus:
            self.watermark = self.watermarkStatus

        self.cam.update()

        self.cam.delete('all')
        
        return

    """
    This function is responsible for using the Blaze to track.

    It is a little more complex, as it requires a treatment to
    the taken points.
    
    But let's talk to the easy part first. First we get the frame
    and the render it at 'native' resolution. After that comes the
    complex part

    First the point are taken. But, the point comes normalized, so
    it's important to convert it to pixel and then remove the not
    needed points as fingers and hands for example. Also in this
    process is fundamental to choose which frames should be used.
    The last element of the points list is the visibility. It works
    as the sureness of the algorithm of that specific point tracked.
    So if the visibility was less than 40%, it'll be discarded.

    This is done to draw the skeleton and then have a fair comparasion
    to the OpenPifPaf method.

    After that, the process is kind of the same of the OpenPifPaf, with
    the exception of the complexity that is also drew at the screen.
    """
    def trackMediaPipe(self):
        frame = self.getFrame()
        img = pilImage.fromarray(frame)

        cameraImg = pilImageTk.PhotoImage(image=img)
        self.cam.create_image(0, 0, image = cameraImg, anchor = NW)

        predictions = self.getBlazePosePrediction(frame)

        fallRisk = 0

        if predictions != []:
            SkeletonDraw.draw(predictions, self.cam, 1, 1, self.debug)

            if self.lastFramePoints != []:
                fallRiskResult = frc.calculateFallRisk(self.lastFramePoints, predictions, 1.0, self.fps, 1280)
                fallRisk = fallRiskResult[0]

                db.insertDatabaseData(predictions, self.dbWB, self.dbRow, fallRiskResult[0], fallRiskResult[1], fallRiskResult[2], fallRiskResult[3])
                self.dbRow += 1
            
            self.lastFramePoints = predictions

        self.cam.create_rectangle(10, 10, 88, 30, fill="#00A5DE", outline="")
        self.cam.create_text(0+49, 20,fill="white",font="Arial 10 bold",text="MediaPipe")

        self.cam.create_rectangle(10, 35, 106, 55, fill="#0076BF", outline="")
        self.cam.create_text(0+56, 45,fill="white",font="Arial 10 bold",text=(("Complexity: %d" % self.complexity)))

        self.cam.create_rectangle(10, 60, 106, 80, fill="#0076BF", outline="")
        self.cam.create_text(0+56, 70,fill="white",font="Arial 10 bold",text=(("FallRisk: %.2f" % fallRisk)))

        self.drawFPS()

        if self.watermark == 0:
            drAlexImg = pilImage.open("Dr.Alex_Watermark.png")
            drAlex_wm = pilImageTk.PhotoImage(image=drAlexImg)
            self.cam.create_image(1280-10, 720-10, image = drAlex_wm, anchor = SE)

            feimmersiveImg = pilImage.open("FEImmersive_Watermark.png")
            feimmersive_wm = pilImageTk.PhotoImage(image=feimmersiveImg)
            self.cam.create_image(10, 720-10, image = feimmersive_wm, anchor = SW)

        if self.watermark != self.watermarkStatus:
            self.watermark = self.watermarkStatus

        self.cam.update()

        self.cam.delete('all')

        return

root = Tk()
root.geometry("1280x720")

myCanvas = App(root)

myCanvas.loop()

root.mainloop()