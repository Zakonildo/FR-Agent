import openpifpaf
import torch

class OpenPifPafTracking:
    def __init__(self):
        self.predictor = openpifpaf.Predictor(checkpoint="shufflenetv2k16")
        self.scale = 1.0
        return
    
    def getPoints(self, img, res):
        imgScaled = img.resize((int(res[0]/self.scale), int(res[1]/self.scale)))
        predictions, gt_anns, image_meta = self.predictor.pil_image(imgScaled)

        if predictions != []:
            for i in range(0, len(predictions)):
                for j in range(0, len(predictions[i].data)):
                    predictions[i].data[j][0] *= self.scale
                    predictions[i].data[j][1] *= self.scale
                    if(predictions[i].data[j][0] > 0 and predictions[i].data[j][1] > 0):
                        predictions[i].data[j][0] += (1600-res[0])/2
                        predictions[i].data[j][1] += (900-res[1])/2

        return predictions, self.scale

    def upScale(self):
        self.scale += 0.1
        self.scale = round(self.scale, 1)

        if(self.scale > 10.0):
            self.scale = 10.0
        
        return True

    def downScale(self):
        self.scale -= 0.1
        self.scale = round(self.scale, 1)

        if(self.scale < 1.0):
            self.scale = 1.0
        
        return True
    
    def resetScale(self):
        self.scale = 1.0

        return True