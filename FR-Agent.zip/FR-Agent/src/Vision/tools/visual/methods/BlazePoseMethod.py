from pickle import TRUE
import torch
import mediapipe as mp
from mediapipe.python.solutions import drawing_utils as mpDU

class BlazePoseTracking:
    def __init__(self):
        self.complexity = 0
        self.predictor = [
            mp.solutions.pose.Pose(model_complexity=0, min_detection_confidence=0.7),
            mp.solutions.pose.Pose(model_complexity=1, min_detection_confidence=0.7),
            mp.solutions.pose.Pose(model_complexity=2, min_detection_confidence=0.7)
            ]
        return
    
    def getPoints(self, img, res):

        predictions = self.predictor[self.complexity].process(img)

        points =[]

        try:
            for i in predictions.pose_landmarks.landmark:
                pixel = mpDU._normalized_to_pixel_coordinates(i.x, i.y, res[0], res[1])
                if pixel != None and i.visibility >= 0.6:
                    points.append([pixel[0] + (1600-res[0])/2, pixel[1] + (900-res[1])/2, i.visibility])
                else:
                    points.append([-1.0, -1.0, i.visibility])

            del points[32]
            del points[31]
            del points[30]
            del points[29]
            del points[22]
            del points[21]
            del points[20]
            del points[19]
            del points[18]
            del points[17]
            del points[10]
            del points[9]
            del points[6]
            del points[4]
            del points[3]
            del points[1]

            return points, self.complexity

        except:
            return [], self.complexity

    def upComplexity(self):
        self.complexity += 1

        if(self.complexity > 2):
            self.complexity = 2
        
        return True

    def downComplexity(self):
        self.complexity -= 1

        if(self.complexity < 0):
            self.complexity = 0
        
        return True
    
    def resetComplexity(self):
        self.complexity = 0

        return TRUE