def drawTextBoxes(p, cam, index):
    for i in range(0, len(p)):
        if p[i][0] > 0.0 and p[i][1] >0.0:
            color = ""
            if i == 0:
                color = "#8803FC" # Nariz
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+40, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+20, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="NOSE " + str(index))

            elif i == 1:
                color = "#FC8803" # Olho Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="EYE_L " + str(index))

            elif i == 2:
                color = "#FC8803" # Olho Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="EYE_R " + str(index))

            elif i == 3:
                color = "#B36A32" # Orelha Esquerda
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="EAR_L " + str(index))

            elif i == 4:
                color = "#B36A32" # Orelha Direita
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="EAR_R " + str(index))

            elif i == 5:
                color = "#75D1C8" # Ombro Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="SHO_L " + str(index))

            elif i == 6:
                color = "#75D1C8" # Ombro Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="SHO_R " + str(index))

            elif i == 7:
                color = "#3A93BD" # Cotovelo Esquerda
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="ELB_L " + str(index))

            elif i == 8:
                color = "#3A93BD" # Cotovelo Direita
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="ELB_R " + str(index))

            elif i == 9:
                color = "#3454E3" # Pulso Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="WRI_L " + str(index))

            elif i == 10:
                color = "#3454E3" # Pulso Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="WRI_R " + str(index))

            elif i == 11:
                color = "#B53C7C" # Quadril Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="HIP_L " + str(index))

            elif i == 12:
                color = "#B53C7C" # Quadril Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="HIP_R " + str(index))
            
            elif i == 13:
                color = "#E33247" # Joelho Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="KNE_L " + str(index))

            elif i == 14:
                color = "#E33247" # Joelho Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="KNE_R " + str(index))

            elif i == 15:
                color = "#00FFAA" # Pé Esquerdo
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="ANK_L " + str(index))

            else:
                color = "#00FFAA" # Pé Direito
                cam.create_rectangle(p[i][0]+20, p[i][1]-20, p[i][0]+20+50, p[i][1]-20-20, fill = color, outline="")
                cam.create_text(p[i][0]+20+25, p[i][1]-20-10,fill="white",font="Arial 10 bold",text="ANK_R " + str(index))
    
    return

def drawPoints(p, cam):
    j = 0

    for i in p:
        color = ""

        if j == 0:
            color = "#8803FC" # Nariz

        elif j <= 2:
            color = "#FC8803" # Olhos

        elif j <= 4:
            color = "#B36A32" # Orelhas

        elif j <= 6:
            color = "#75D1C8" # Ombros

        elif j <= 8:
            color = "#3A93BD" # Mãos

        elif j <= 10:
            color = "#3454E3" # Cotovelos

        elif j <= 12:
            color = "#B53C7C" # Quadril
        
        elif j <= 14:
            color = "#E33247" # Joelhos

        else:
            color = "#00FFAA" # Pés

        if(i[0] > 0.0 and i[1] > 0.0):
            cam.create_oval(i[0]-5, i[1]-5, i[0]+5, i[1]+5, fill = color, outline="")

        j += 1
    return

def drawJoints(p, cam):
    if p[3][0] > 0.0 and p[3][1] > 0.0 and p[1][0] > 0.0 and p[1][1] > 0:
        cam.create_line(p[3][0], p[3][1], p[1][0], p[1][1], fill = "#3C3C3C", width= 5)

    if p[1][0] > 0.0 and p[1][1] > 0.0 and p[0][0] > 0.0 and p[0][1] > 0:
        cam.create_line(p[1][0], p[1][1], p[0][0], p[0][1], fill = "#3C3C3C", width= 5)

    if p[0][0] > 0.0 and p[0][1] > 0.0 and p[2][0] > 0.0 and p[2][1] > 0:
        cam.create_line(p[0][0], p[0][1], p[2][0], p[2][1], fill = "#3C3C3C", width= 5)

    if p[2][0] > 0.0 and p[2][1] > 0.0 and p[4][0] > 0.0 and p[4][1] > 0:
        cam.create_line(p[2][0], p[2][1], p[4][0], p[4][1], fill = "#3C3C3C", width= 5)

    if (p[5][0] > 0.0 and p[5][1] > 0.0) or (p[6][0] > 0.0 and p[6][1] > 0):

        if p[3][0] > 0.0 and p[3][1] > 0.0 and p[5][0] > 0.0 and p[5][1] > 0:
            cam.create_line(p[3][0], p[3][1], p[5][0], p[5][1], fill = "#3C3C3C", width= 5)

        if p[4][0] > 0.0 and p[4][1] > 0.0 and p[6][0] > 0.0 and p[6][1] > 0:
            cam.create_line(p[4][0], p[4][1], p[6][0], p[6][1], fill = "#3C3C3C", width= 5)

        if p[3][0] == 0.0 and p[3][1] == 0.0 and p[4][0] == 0.0 and p[4][1] == 0 and p[6][0] > 0.0 and p[6][1] > 0 and p[5][0] > 0.0 and p[5][1] > 0 and p[0][0] > 0.0 and p[0][1] > 0.0:
            cam.create_line(p[0][0], p[0][1], p[5][0], p[5][1], fill = "#3C3C3C", width= 5)

            cam.create_line(p[0][0], p[0][1], p[6][0], p[6][1], fill = "#3C3C3C", width= 5)

        if p[7][0] > 0.0 and p[7][1] > 0.0 and p[5][0] > 0.0 and p[5][1] > 0:
            cam.create_line(p[7][0], p[7][1], p[5][0], p[5][1], fill = "#3C3C3C", width= 5)

        if p[8][0] > 0.0 and p[8][1] > 0.0 and p[6][0] > 0.0 and p[6][1] > 0:
            cam.create_line(p[8][0], p[8][1], p[6][0], p[6][1], fill = "#3C3C3C", width= 5)

        if p[11][0] > 0.0 and p[11][1] > 0.0 and p[5][0] > 0.0 and p[5][1] > 0:
            cam.create_line(p[11][0], p[11][1], p[5][0], p[5][1], fill = "#3C3C3C", width= 5)

        if p[12][0] > 0.0 and p[12][1] > 0.0 and p[6][0] > 0.0 and p[6][1] > 0:
            cam.create_line(p[12][0], p[12][1], p[6][0], p[6][1], fill = "#3C3C3C", width= 5)

        if p[5][0] > 0.0 and p[5][1] > 0.0 and p[6][0] > 0.0 and p[6][1] > 0:
            cam.create_line(p[5][0], p[5][1], p[6][0], p[6][1], fill = "#3C3C3C", width= 5)

    if (p[7][0] > 0.0 and p[7][1] > 0.0) or (p[8][0] > 0.0 and p[8][1] > 0):

        if p[7][0] > 0.0 and p[7][1] > 0.0 and p[9][0] > 0.0 and p[9][1] > 0:
            cam.create_line(p[7][0], p[7][1], p[9][0], p[9][1], fill = "#3C3C3C", width= 5)

        if p[8][0] > 0.0 and p[8][1] > 0.0 and p[10][0] > 0.0 and p[10][1] > 0:
            cam.create_line(p[8][0], p[8][1], p[10][0], p[10][1], fill = "#3C3C3C", width= 5)

    if (p[11][0] > 0.0 and p[11][1] > 0.0) or (p[12][0] > 0.0 and p[12][1] > 0):

        if p[11][0] > 0.0 and p[11][1] > 0.0 and p[13][0] > 0.0 and p[13][1] > 0:
            cam.create_line(p[11][0], p[11][1], p[13][0], p[13][1], fill = "#3C3C3C", width= 5)

        if p[12][0] > 0.0 and p[12][1] > 0.0 and p[14][0] > 0.0 and p[14][1] > 0:
            cam.create_line(p[12][0], p[12][1], p[14][0], p[14][1], fill = "#3C3C3C", width= 5)

        if p[11][0] > 0.0 and p[11][1] > 0.0 and p[12][0] > 0.0 and p[12][1] > 0:
            cam.create_line(p[11][0], p[11][1], p[12][0], p[12][1], fill = "#3C3C3C", width= 5)

    if (p[13][0] > 0.0 and p[13][1] > 0.0) or (p[14][0] > 0.0 and p[14][1] > 0):
        if p[15][0] > 0.0 and p[15][1] > 0.0 and p[13][0] > 0.0 and p[13][1] > 0:
            cam.create_line(p[15][0], p[15][1], p[13][0], p[13][1], fill = "#3C3C3C", width= 5)

        if p[16][0] > 0.0 and p[16][1] > 0.0 and p[14][0] > 0.0 and p[14][1] > 0:
            cam.create_line(p[16][0], p[16][1], p[14][0], p[14][1], fill = "#3C3C3C", width= 5)
    return

def debugPoints(p, cam):
    x = 1280 - 1280/16
    y = 100
    for i in p:
        cam.create_rectangle(x-60, y-10, x+60, y+10, fill="#0076BF", outline="")
        cam.create_text(x, y,fill="white",font="Arial 10 bold",text=("( %.1f, %.1f )" % ( i[0], i[1]) ) )
        y += 30
    
    return

def draw(p, cam, index, debug=0):
    drawJoints(p, cam)
    drawTextBoxes(p, cam, index)
    drawPoints(p, cam)

    if debug == 1:
        debugPoints(p, cam)
        

    return