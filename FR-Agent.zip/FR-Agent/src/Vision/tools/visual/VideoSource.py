from operator import is_
import cv2
import os
import time


class VideoSource:
    def __init__(self):
        try:
            #self.camera = cv2.VideoCapture(2 + cv2.CAP_DSHOW)
            self.camera = cv2.VideoCapture(os.getcwd() + "\\tools\\visual\\Videos Samples\\BF_01.mp4")
            self.height = self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
            self.width = self.camera.get(cv2.CAP_PROP_FRAME_WIDTH)
            self.videoTestOrder = [
                "BF_01.mp4",
                "BF_02.mp4",
                "BF_03.mp4",
                "BF_04.mp4",
                "BF_05.mp4",
                "BF_07.mp4",
                "BF_08.mp4",
                "BF_09.mp4",
                "BF_10.mp4",
                "FCF_01.mp4",
                "FCF_02.mp4",
                "FCF_03.mp4",
                "FCF_04.mp4",
                "NF_01.mp4",
                "NF_02.mp4",
                "NF_03.mp4",
                "NF_04.mp4",
                "NF_05.mp4",
                "NF_06.mp4",
                "NF_07.mp4",
                "NF_08.mp4",
                "NF_09.mp4",
                "NF_10.mp4",
                "NF_11.mp4",
                "NF_12.mp4",
                "NF_13.mp4",
                "SCF_01.mp4",
                "SCF_02.mp4",
                "SCF_03.mp4",
                "SCF_04.mp4",
                "WF_01.mp4",
                "WF_02.mp4",
                "WF_04.mp4",
                "WF_05.mp4",
                "WF_06.mp4",
                "WF_07.mp4",
                "WF_10.mp4",
                "WF_11.mp4",
                "WF_12.mp4",
                "WF_13.mp4",
                ]
            self.fallIndex = 0
        except:
            self.camera = None
            self.height = None
            self.width = None
            self.videoTestOrder = [
                "BF_01.mp4",
                "BF_02.mp4",
                "BF_03.mp4",
                "BF_04.mp4",
                "BF_05.mp4",
                "BF_07.mp4",
                "BF_08.mp4",
                "BF_09.mp4",
                "BF_10.mp4",
                "FCF_01.mp4",
                "FCF_02.mp4",
                "FCF_03.mp4",
                "FCF_04.mp4",
                "NF_01.mp4",
                "NF_02.mp4",
                "NF_03.mp4",
                "NF_04.mp4",
                "NF_05.mp4",
                "NF_06.mp4",
                "NF_07.mp4",
                "NF_08.mp4",
                "NF_09.mp4",
                "NF_10.mp4",
                "NF_11.mp4",
                "NF_12.mp4",
                "NF_13.mp4",
                "SCF_01.mp4",
                "SCF_02.mp4",
                "SCF_03.mp4",
                "SCF_04.mp4",
                "WF_01.mp4",
                "WF_02.mp4",
                "WF_04.mp4",
                "WF_05.mp4",
                "WF_06.mp4",
                "WF_07.mp4",
                "WF_10.mp4",
                "WF_11.mp4",
                "WF_12.mp4",
                "WF_13.mp4",
                ]
            self.fallIndex = 0

        return

    def getFrame(self):
        if self.camera != None:
            try:
                check, frame = self.camera.read()
                return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), False
            except:
                self.camera.release()
                self.camera = cv2.VideoCapture(os.getcwd() + "\\tools\\visual\\Videos Samples\\PS.mp4")
                check, frame = self.camera.read()
                self.height = self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
                self.width = self.camera.get(cv2.CAP_PROP_FRAME_WIDTH)
                return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), False

    def groundTruthGetFrame(self):
        if self.camera != None:
            try:
                check, frame = self.camera.read()
                return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), False
            except:
                self.camera.release()
                self.fallIndex += 1
                if(self.fallIndex >= 40):
                    self.fallIndex = 0
                self.camera = cv2.VideoCapture(os.getcwd() + "\\tools\\visual\\Videos Samples\\" + self.videoTestOrder[self.fallIndex])
                check, frame = self.camera.read()
                self.height = self.camera.get(cv2.CAP_PROP_FRAME_HEIGHT)
                self.width = self.camera.get(cv2.CAP_PROP_FRAME_WIDTH)
                return cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), True

    def getResolution(self):
        if self.camera != None:
            return self.width, self.height