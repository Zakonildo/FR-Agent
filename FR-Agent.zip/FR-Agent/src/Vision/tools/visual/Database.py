import os
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, PatternFill, Font
import datetime

def checkDatabase(name):
    dirs = os.listdir()
    if name + ".xlsx" in dirs:
        return True
    else:
        return False

def loadDatabase(name):
    dbName = name
    dbWB = load_workbook(dbName + ".xlsx")
    dbWS = dbWB.active
    dbRow = 1
    while dbWS.cell(row=dbRow, column=1).value != None:
        dbRow += 1

    return dbWB, dbRow

def insertDatabaseData(trackedPoints, dbWB, dbRow, p_fr, s_k_i, s_fps, s_res, fps):
    dbColumn = 1
    dbWS = dbWB.active
    time = datetime.datetime.now()
    
    for i in trackedPoints:
        dbWS.cell(row=dbRow, column=dbColumn, value=i[0])
        dbWS.cell(row=dbRow, column=dbColumn + 1, value=i[1])
        dbWS.cell(row=dbRow, column=dbColumn + 2, value=time)
        dbColumn += 3
    
    dbWS.cell(row=dbRow, column=dbColumn, value=p_fr)
    dbWS.cell(row=dbRow, column=dbColumn + 1, value=s_k_i)
    dbWS.cell(row=dbRow, column=dbColumn + 2, value=s_res)
    dbWS.cell(row=dbRow, column=dbColumn + 3, value=s_fps)
    dbWS.cell(row=dbRow, column=dbColumn + 4, value=fps)

    return True

def createDatabase(name):
    dbName = name
    dbWB = Workbook()
    dbWS = dbWB.active

    dbFontH1 = Font( color="FFFFFF", bold=True, size=20 )
    dbFontH2 = Font( color="FFFFFF", bold=True, size=16 )

    dbAlignment = Alignment( horizontal="center" )

    dbFillA = PatternFill(patternType="solid", fgColor= "1D65E0")
    dbFillB = PatternFill(patternType="solid", fgColor= "1A37AD")
    dbFillX = PatternFill(patternType="solid", fgColor= "1A6EAD")
    dbFillY = PatternFill(patternType="solid", fgColor= "114973")
    dbFillConf = PatternFill(patternType="solid", fgColor= "242424")

    dbLabel1 = "x"
    dbLabel2 = "y"
    dbLabel3 = "TIME"

    dbWS["A1"] = "NOSE"           # 01
    dbWS.merge_cells("A1:C1")
    dbWS["A1"].font = dbFontH1
    dbWS["A1"].alignment = dbAlignment
    dbWS["A1"].fill = dbFillA
    dbWS["A2"] = dbLabel1
    dbWS["B2"] = dbLabel2
    dbWS["C2"] = dbLabel3
    dbWS["A2"].font = dbFontH2
    dbWS["B2"].font = dbFontH2
    dbWS["C2"].font = dbFontH2
    dbWS["A2"].alignment = dbAlignment
    dbWS["B2"].alignment = dbAlignment
    dbWS["C2"].alignment = dbAlignment
    dbWS["A2"].fill = dbFillX
    dbWS["B2"].fill = dbFillY
    dbWS["C2"].fill = dbFillConf

    dbWS["D1"] = "LEFT_EYE"       # 02
    dbWS.merge_cells("D1:F1")
    dbWS["D1"].font = dbFontH1
    dbWS["D1"].alignment = dbAlignment
    dbWS["D1"].fill = dbFillB
    dbWS["D2"] = dbLabel1
    dbWS["E2"] = dbLabel2
    dbWS["F2"] = dbLabel3
    dbWS["D2"].font = dbFontH2
    dbWS["E2"].font = dbFontH2
    dbWS["F2"].font = dbFontH2
    dbWS["D2"].alignment = dbAlignment
    dbWS["E2"].alignment = dbAlignment
    dbWS["F2"].alignment = dbAlignment
    dbWS["D2"].fill = dbFillX
    dbWS["E2"].fill = dbFillY
    dbWS["F2"].fill = dbFillConf

    dbWS["G1"] = "RIGHT_EYE"      # 03
    dbWS.merge_cells("G1:I1")
    dbWS["G1"].font = dbFontH1
    dbWS["G1"].alignment = dbAlignment
    dbWS["G1"].fill = dbFillA
    dbWS["G2"] = dbLabel1
    dbWS["H2"] = dbLabel2
    dbWS["I2"] = dbLabel3
    dbWS["G2"].font = dbFontH2
    dbWS["H2"].font = dbFontH2
    dbWS["I2"].font = dbFontH2
    dbWS["G2"].alignment = dbAlignment
    dbWS["H2"].alignment = dbAlignment
    dbWS["I2"].alignment = dbAlignment
    dbWS["G2"].fill = dbFillX
    dbWS["H2"].fill = dbFillY
    dbWS["I2"].fill = dbFillConf

    dbWS["J1"] = "LEFT_EAR"       # 04
    dbWS.merge_cells("J1:L1")
    dbWS["J1"].font = dbFontH1
    dbWS["J1"].alignment = dbAlignment
    dbWS["J1"].fill = dbFillB
    dbWS["J2"] = dbLabel1
    dbWS["K2"] = dbLabel2
    dbWS["L2"] = dbLabel3
    dbWS["J2"].font = dbFontH2
    dbWS["K2"].font = dbFontH2
    dbWS["L2"].font = dbFontH2
    dbWS["J2"].alignment = dbAlignment
    dbWS["K2"].alignment = dbAlignment
    dbWS["L2"].alignment = dbAlignment
    dbWS["J2"].fill = dbFillX
    dbWS["K2"].fill = dbFillY
    dbWS["L2"].fill = dbFillConf

    dbWS["M1"] = "RIGHT_EAR"      # 05
    dbWS.merge_cells("M1:O1")
    dbWS["M1"].font = dbFontH1
    dbWS["M1"].alignment = dbAlignment
    dbWS["M1"].fill = dbFillA
    dbWS["M2"] = dbLabel1
    dbWS["N2"] = dbLabel2
    dbWS["O2"] = dbLabel3
    dbWS["M2"].font = dbFontH2
    dbWS["N2"].font = dbFontH2
    dbWS["O2"].font = dbFontH2
    dbWS["M2"].alignment = dbAlignment
    dbWS["N2"].alignment = dbAlignment
    dbWS["O2"].alignment = dbAlignment
    dbWS["M2"].fill = dbFillX
    dbWS["N2"].fill = dbFillY
    dbWS["O2"].fill = dbFillConf

    dbWS["P1"] = "LEFT_SHOULDER"  # 06
    dbWS.merge_cells("P1:R1")
    dbWS["P1"].font = dbFontH1
    dbWS["P1"].alignment = dbAlignment
    dbWS["P1"].fill = dbFillB
    dbWS["P2"] = dbLabel1
    dbWS["Q2"] = dbLabel2
    dbWS["R2"] = dbLabel3
    dbWS["P2"].font = dbFontH2
    dbWS["Q2"].font = dbFontH2
    dbWS["R2"].font = dbFontH2
    dbWS["P2"].alignment = dbAlignment
    dbWS["Q2"].alignment = dbAlignment
    dbWS["R2"].alignment = dbAlignment
    dbWS["P2"].fill = dbFillX
    dbWS["Q2"].fill = dbFillY
    dbWS["R2"].fill = dbFillConf

    dbWS["S1"] = "RIGHT_SHOULDER" # 07
    dbWS.merge_cells("S1:U1")
    dbWS["S1"].font = dbFontH1
    dbWS["S1"].alignment = dbAlignment
    dbWS["S1"].fill = dbFillA
    dbWS["S2"] = dbLabel1
    dbWS["T2"] = dbLabel2
    dbWS["U2"] = dbLabel3
    dbWS["S2"].font = dbFontH2
    dbWS["T2"].font = dbFontH2
    dbWS["U2"].font = dbFontH2
    dbWS["S2"].alignment = dbAlignment
    dbWS["T2"].alignment = dbAlignment
    dbWS["U2"].alignment = dbAlignment
    dbWS["S2"].fill = dbFillX
    dbWS["T2"].fill = dbFillY
    dbWS["U2"].fill = dbFillConf

    dbWS["V1"] = "LEFT_ELBOW"     # 08
    dbWS.merge_cells("V1:X1")
    dbWS["V1"].font = dbFontH1
    dbWS["V1"].alignment = dbAlignment
    dbWS["V1"].fill = dbFillB
    dbWS["V2"] = dbLabel1
    dbWS["W2"] = dbLabel2
    dbWS["X2"] = dbLabel3
    dbWS["V2"].font = dbFontH2
    dbWS["W2"].font = dbFontH2
    dbWS["X2"].font = dbFontH2
    dbWS["V2"].alignment = dbAlignment
    dbWS["W2"].alignment = dbAlignment
    dbWS["X2"].alignment = dbAlignment
    dbWS["V2"].fill = dbFillX
    dbWS["W2"].fill = dbFillY
    dbWS["X2"].fill = dbFillConf

    dbWS["Y1"] = "RIGHT_ELBOW"    # 09
    dbWS.merge_cells("Y1:AA1")
    dbWS["Y1"].font = dbFontH1
    dbWS["Y1"].alignment = dbAlignment
    dbWS["Y1"].fill = dbFillA
    dbWS["Y2"] = dbLabel1
    dbWS["Z2"] = dbLabel2
    dbWS["AA2"] = dbLabel3
    dbWS["Y2"].font = dbFontH2
    dbWS["Z2"].font = dbFontH2
    dbWS["AA2"].font = dbFontH2
    dbWS["Y2"].alignment = dbAlignment
    dbWS["Z2"].alignment = dbAlignment
    dbWS["AA2"].alignment = dbAlignment
    dbWS["Y2"].fill = dbFillX
    dbWS["Z2"].fill = dbFillY
    dbWS["AA2"].fill = dbFillConf

    dbWS["AB1"] = "LEFT_WRIST"    # 10
    dbWS.merge_cells("AB1:AD1")
    dbWS["AB1"].font = dbFontH1
    dbWS["AB1"].alignment = dbAlignment
    dbWS["AB1"].fill = dbFillB
    dbWS["AB2"] = dbLabel1
    dbWS["AC2"] = dbLabel2
    dbWS["AD2"] = dbLabel3
    dbWS["AB2"].font = dbFontH2
    dbWS["AC2"].font = dbFontH2
    dbWS["AD2"].font = dbFontH2
    dbWS["AB2"].alignment = dbAlignment
    dbWS["AC2"].alignment = dbAlignment
    dbWS["AD2"].alignment = dbAlignment
    dbWS["AB2"].fill = dbFillX
    dbWS["AC2"].fill = dbFillY
    dbWS["AD2"].fill = dbFillConf

    dbWS["AE1"] = "RIGHT_WRIST"   # 11
    dbWS.merge_cells("AE1:AG1")
    dbWS["AE1"].font = dbFontH1
    dbWS["AE1"].alignment = dbAlignment
    dbWS["AE1"].fill = dbFillA
    dbWS["AE2"] = dbLabel1
    dbWS["AF2"] = dbLabel2
    dbWS["AG2"] = dbLabel3
    dbWS["AE2"].font = dbFontH2
    dbWS["AF2"].font = dbFontH2
    dbWS["AG2"].font = dbFontH2
    dbWS["AE2"].alignment = dbAlignment
    dbWS["AF2"].alignment = dbAlignment
    dbWS["AG2"].alignment = dbAlignment
    dbWS["AE2"].fill = dbFillX
    dbWS["AF2"].fill = dbFillY
    dbWS["AG2"].fill = dbFillConf

    dbWS["AH1"] = "LEFT_HIP"      # 12
    dbWS.merge_cells("AH1:AJ1")
    dbWS["AH1"].font = dbFontH1
    dbWS["AH1"].alignment = dbAlignment
    dbWS["AH1"].fill = dbFillB
    dbWS["AH2"] = dbLabel1
    dbWS["AI2"] = dbLabel2
    dbWS["AJ2"] = dbLabel3
    dbWS["AH2"].font = dbFontH2
    dbWS["AI2"].font = dbFontH2
    dbWS["AJ2"].font = dbFontH2
    dbWS["AH2"].alignment = dbAlignment
    dbWS["AI2"].alignment = dbAlignment
    dbWS["AJ2"].alignment = dbAlignment
    dbWS["AH2"].fill = dbFillX
    dbWS["AI2"].fill = dbFillY
    dbWS["AJ2"].fill = dbFillConf

    dbWS["AK1"] = "RIGHT_HIP"     # 13
    dbWS.merge_cells("AK1:AM1")
    dbWS["AK1"].font = dbFontH1
    dbWS["AK1"].alignment = dbAlignment
    dbWS["AK1"].fill = dbFillA
    dbWS["AK2"] = dbLabel1
    dbWS["AL2"] = dbLabel2
    dbWS["AM2"] = dbLabel3
    dbWS["AK2"].font = dbFontH2
    dbWS["AL2"].font = dbFontH2
    dbWS["AM2"].font = dbFontH2
    dbWS["AK2"].alignment = dbAlignment
    dbWS["AL2"].alignment = dbAlignment
    dbWS["AM2"].alignment = dbAlignment
    dbWS["AK2"].fill = dbFillX
    dbWS["AL2"].fill = dbFillY
    dbWS["AM2"].fill = dbFillConf

    dbWS["AN1"] = "LEFT_KNEE"     # 14
    dbWS.merge_cells("AN1:AP1")
    dbWS["AN1"].font = dbFontH1
    dbWS["AN1"].alignment = dbAlignment
    dbWS["AN1"].fill = dbFillB
    dbWS["AN2"] = dbLabel1
    dbWS["AO2"] = dbLabel2
    dbWS["AP2"] = dbLabel3
    dbWS["AN2"].font = dbFontH2
    dbWS["AO2"].font = dbFontH2
    dbWS["AP2"].font = dbFontH2
    dbWS["AN2"].alignment = dbAlignment
    dbWS["AO2"].alignment = dbAlignment
    dbWS["AP2"].alignment = dbAlignment
    dbWS["AN2"].fill = dbFillX
    dbWS["AO2"].fill = dbFillY
    dbWS["AP2"].fill = dbFillConf

    dbWS["AQ1"] = "RIGHT_KNEE"    # 15
    dbWS.merge_cells("AQ1:AS1")
    dbWS["AQ1"].font = dbFontH1
    dbWS["AQ1"].alignment = dbAlignment
    dbWS["AQ1"].fill = dbFillA
    dbWS["AQ2"] = dbLabel1
    dbWS["AR2"] = dbLabel2
    dbWS["AS2"] = dbLabel3
    dbWS["AQ2"].font = dbFontH2
    dbWS["AR2"].font = dbFontH2
    dbWS["AS2"].font = dbFontH2
    dbWS["AQ2"].alignment = dbAlignment
    dbWS["AR2"].alignment = dbAlignment
    dbWS["AS2"].alignment = dbAlignment
    dbWS["AQ2"].fill = dbFillX
    dbWS["AR2"].fill = dbFillY
    dbWS["AS2"].fill = dbFillConf

    dbWS["AT1"] = "LEFT_ANKLE"    # 16
    dbWS.merge_cells("AT1:AV1")
    dbWS["AT1"].font = dbFontH1
    dbWS["AT1"].alignment = dbAlignment
    dbWS["AT1"].fill = dbFillB
    dbWS["AT2"] = dbLabel1
    dbWS["AU2"] = dbLabel2
    dbWS["AV2"] = dbLabel3
    dbWS["AT2"].font = dbFontH2
    dbWS["AU2"].font = dbFontH2
    dbWS["AV2"].font = dbFontH2
    dbWS["AT2"].alignment = dbAlignment
    dbWS["AU2"].alignment = dbAlignment
    dbWS["AV2"].alignment = dbAlignment
    dbWS["AT2"].fill = dbFillX
    dbWS["AU2"].fill = dbFillY
    dbWS["AV2"].fill = dbFillConf

    dbWS["AW1"] = "RIGHT_ANKLE"   # 17
    dbWS.merge_cells("AW1:AY1")
    dbWS["AW1"].font = dbFontH1
    dbWS["AW1"].alignment = dbAlignment
    dbWS["AW1"].fill = dbFillA
    dbWS["AW2"] = dbLabel1
    dbWS["AX2"] = dbLabel2
    dbWS["AY2"] = dbLabel3
    dbWS["AW2"].font = dbFontH2
    dbWS["AX2"].font = dbFontH2
    dbWS["AY2"].font = dbFontH2
    dbWS["AW2"].alignment = dbAlignment
    dbWS["AX2"].alignment = dbAlignment
    dbWS["AY2"].alignment = dbAlignment
    dbWS["AW2"].fill = dbFillX
    dbWS["AX2"].fill = dbFillY
    dbWS["AY2"].fill = dbFillConf

    dbWS["AZ1"] = "FALL_RISK"   # FALL_RISK
    dbWS.merge_cells("AZ1:BD1")
    dbWS["AZ1"].font = dbFontH1
    dbWS["AZ1"].alignment = dbAlignment
    dbWS["AZ1"].fill = dbFillB
    dbWS["AZ2"] = "Probability"
    dbWS["BA2"] = "S_k_i"
    dbWS["BB2"] = "S_res"
    dbWS["BC2"] = "S_fps"
    dbWS["BD2"] = "FPS"
    dbWS["AZ2"].font = dbFontH2
    dbWS["BA2"].font = dbFontH2
    dbWS["BB2"].font = dbFontH2
    dbWS["BC2"].font = dbFontH2
    dbWS["BD2"].font = dbFontH2
    dbWS["AZ2"].alignment = dbAlignment
    dbWS["BA2"].alignment = dbAlignment
    dbWS["BB2"].alignment = dbAlignment
    dbWS["BC2"].alignment = dbAlignment
    dbWS["BD2"].alignment = dbAlignment
    dbWS["AZ2"].fill = dbFillX
    dbWS["BA2"].fill = dbFillY
    dbWS["BB2"].fill = dbFillX
    dbWS["BC2"].fill = dbFillY
    dbWS["BD2"].fill = dbFillX

    dbWB.save(dbName + ".xlsx")

    return True