from app import *
def main():
    App = DrAlex()
    App.run()
    return

 
if (__name__ == "__main__"):
    main()